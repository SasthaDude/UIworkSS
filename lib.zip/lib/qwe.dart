import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class asd extends StatelessWidget {
  const asd({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [

        GestureDetector(
          onTap: ()
          {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const poi()),
            );
          },
          child: Container(
            height: 100,
            width: 100,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/dog.png"),
                fit: BoxFit.fill,
              )
            ),
          ),
        ),

        ElevatedButton(
            onPressed: ()
            {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const poi()),
              );
        }, child: Text("ok"))
      ],
    );
  }
}


class poi extends StatelessWidget {
  const poi({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: 100,
      color: Colors.red,
    );
  }
}
