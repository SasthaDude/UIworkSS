import 'package:flutter/material.dart';
import 'package:untitled/qwe.dart';
import 'package:untitled/report.dart';

class abc extends StatefulWidget {
  const abc({super.key});

  @override
  State<abc> createState() => _abcState();
}

class _abcState extends State<abc> {

  int index = 0;


  final screens = [
    lmn(),
    asd()
  ];

  void tap(_index)
  {
    setState(() {
      index = _index;

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[index],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.settings),label: "Settings"),
        ],
        currentIndex: index,
        onTap: tap,

      )
    );
  }
}

