import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:untitled/bot%20navigation.dart';

class dfg extends StatefulWidget {
  const dfg({super.key});

  @override
  State<dfg> createState() => _dfgState();
}

class _dfgState extends State<dfg> {
  TextEditingController sd=TextEditingController();
  final _key = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _key,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  icon: Icon(Icons.person),
                  hintText: "Enter the name",
                ),
                validator: (a){
                  if(a == null || a.isEmpty)
                    {
                      return "Invalid name";
                    }
                }
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: sd,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  icon: Icon(Icons.password),
                  hintText: "Enter the password",
                ),
              ),
            ),
            Visibility(
              visible: sd.text.isNotEmpty,
              child: ElevatedButton(
                  onPressed: (){
                    setState(() {
                     //show = true;
                    });
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const abc()),
                    );
                  }, child: Icon(Icons.login)),
            ),
          ],
        ),
      ),
    );
  }
}
